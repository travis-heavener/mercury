# Security Policy

## Supported Versions

Mercury is still in its early development stages, so any release is subject to change in future updates.

Security improvements and other performance improvements are added in each new release as there are no LTS versions.

## Reporting a Vulnerability

Report a vulnerability to [Travis Heavener](https://github.com/travis-heavener) via email, or submit an issue on this repository.
